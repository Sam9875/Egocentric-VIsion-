SO when you want to run the vslbase model you have to replace these files in vslnet to convert it to vslbase
replace the main of vslnet to the given main file in this folder
same for the vslnet.py and runners

 (basically removing the query highlighted part so we can use the vslbase instead of vslnet)